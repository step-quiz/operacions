/**
 * ============================================================================
 * PROJECTE: Motor Educatiu de Derivades (Vanilla JS)
 * FITXER: js/derivades/derivades.js
 * ROL: Controlador específic del joc de derivades.
 * ARQUITECTURA:
 * - FASE 4: Feedback ampliat per a l'alumne. Dos nivells de feedback:
 *   1. Feedback immediat (opt.feedback): sempre visible en error.
 *   2. Hint ampliat (DistractorLib.FeedbackHints[errorType]): explicació
 *      conceptual del tipus d'error, visible en bloc separat sota el feedback.
 *      Només apareix si existeix entrada a FeedbackHints per aquell errorType.
 *   3. Resposta correcta: visible quan s'esgoten tots els intents, renderitzada
 *      amb KaTeX dins el feedback container. game-core.js és intocable, de
 *      manera que la resposta correcta s'injecta al feedback container propi
 *      de derivades.js, no al mini-overlay de game-core.js.
 * - errorHistory[]: registre paral·lel d'errorType iniciat a la Fase 3,
 *   ara usat per construir el resum final d'errors conceptuals.
 * DEPENDÈNCIES: Mòdul ES (<script type="module">). Importa distractor-lib i
 *   question-bank (que al seu torn importen math-engine i strings), i la base
 *   compartida: config.js, utils.js i game-core.js (estat de la partida a `state`).
 * ============================================================================
 */

import { MAX_INTENTS, TOTAL_OPERATIONS } from '../config.js';
import { shuffle } from '../utils.js';
import {
    state,
    endSession,
    injectSharedHTML,
    recordAnswerToHistory,
    startGame,
    validateConfig,
} from '../game-core.js';
import { DistractorLib } from './distractor-lib.js';
import { QuestionBank } from './question-bank.js';

// Aquest fitxer és un mòdul ES: les seves funcions no són globals. Exposem a
// window només les que es criden des de fora: game-core.js (buildLevel) i els onclick de l'HTML.
// Les crides internes fan servir window.buildLevel() perquè les sessions fixes
// (js/fixed-sessions.js) hi puguin afegir la llavor de cada pregunta.
Object.assign(window, { buildLevel });

let errorHistory = [];
let challengeData = null;

const els = {
    fxDisplay: document.getElementById('fx-display'),
    optionsContainer: document.getElementById('options-container'),
    feedback: document.getElementById('missatge-feedback'),
    scoreDisplay: document.getElementById('score-display'),
    lvlDisplay: document.getElementById('lvl-display'),
    attemptsDisplay: document.getElementById('attempts-display'),
};

// =========================================================================
// 1. Construeix un nou nivell
// =========================================================================
function buildLevel() {
    state.isTransitioning = false;
    state.attemptsLeft = MAX_INTENTS;

    els.lvlDisplay.innerText = `Funció ${state.currentOperation + 1} de ${TOTAL_OPERATIONS}`;
    els.attemptsDisplay.innerText = `Intents: ${state.attemptsLeft}`;
    els.feedback.style.opacity = '0';
    els.feedback.innerHTML = '';

    challengeData = QuestionBank.generateChallenge();

    katex.render(challengeData.promptTex, els.fxDisplay, { throwOnError: false });

    const allOptions = shuffle([...challengeData.options]);

    els.optionsContainer.innerHTML = '';
    allOptions.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = 'btn-option';
        const span = document.createElement('span');
        katex.render(opt.tex, span, { throwOnError: false });
        btn.appendChild(span);
        btn.onclick = () => checkAnswer(opt, btn);
        els.optionsContainer.appendChild(btn);
    });
}

// =========================================================================
// 2. Renderitza el feedback (dos nivells + resposta correcta opcional)
// =========================================================================

/**
 * Renderitza el bloc de feedback complet dins els.feedback.
 * @param {object}  opt            - L'opció clicada (té .feedback, .errorType, .isCorrect)
 * @param {boolean} showSolution   - Si true, mostra la resposta correcta amb KaTeX
 */
function renderFeedback(opt, showSolution = false) {
    const fc = els.feedback;

    if (opt.isCorrect) {
        fc.innerHTML = `<strong class="feedback-correct">${opt.feedback}</strong>`;
        fc.style.opacity = '1';
        return;
    }

    // --- Nivell 1: feedback immediat (innerHTML primer) ---
    fc.innerHTML = `<span class="feedback-wrong">${opt.feedback}</span>`;
    fc.style.opacity = '1';

    // --- Nivell 2: botó "+ ajuda" que desplega el hint (si existeix) ---
    const hint = DistractorLib.FeedbackHints[opt.errorType];
    if (hint) {
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'hint-toggle-btn';
        toggleBtn.textContent = '+ ajuda';

        const hintBox = document.createElement('div');
        hintBox.className = 'hint-box';
        hintBox.textContent = hint;
        hintBox.style.display = 'none';

        toggleBtn.addEventListener('click', () => {
            const isHidden = hintBox.style.display === 'none';
            hintBox.style.display = isHidden ? 'block' : 'none';
            toggleBtn.textContent = isHidden ? '− ajuda' : '+ ajuda';
        });

        fc.appendChild(document.createElement('br'));
        fc.appendChild(toggleBtn);
        fc.appendChild(hintBox);
    }

    // --- Nivell 3: resposta correcta (quan s'esgoten els intents) ---
    if (showSolution && challengeData?.solutionTex) {
        const solutionRow = document.createElement('div');
        solutionRow.className = 'solution-reveal';

        const label = document.createElement('span');
        label.className = 'solution-label';
        label.innerText = 'La resposta correcta era:';

        const formula = document.createElement('span');
        formula.className = 'solution-formula';
        katex.render(challengeData.solutionTex, formula, { throwOnError: false });

        solutionRow.appendChild(label);
        solutionRow.appendChild(formula);
        fc.appendChild(solutionRow);
    }
}

// =========================================================================
// 3. Comprova la resposta seleccionada
// =========================================================================
function checkAnswer(opt, clickedBtn) {
    if (state.isTransitioning) return;

    if (opt.isCorrect) {
        state.isTransitioning = true;
        renderFeedback(opt);

        recordAnswerToHistory(challengeData.promptTex, opt.tex, true);
        errorHistory.push({
            question: challengeData.promptTex,
            questionN: state.currentOperation,
            errorType: null,
            isCorrect: true,
            meta: challengeData.meta,
        });

        const fails = MAX_INTENTS - state.attemptsLeft;
        const levelPoints = Math.max(0, 10 - fails * 2);
        state.sessionScore += levelPoints;
        els.scoreDisplay.innerText = `Punts: ${state.sessionScore}`;

        Array.from(els.optionsContainer.children).forEach(b => (b.style.pointerEvents = 'none'));
        _showNextButton(levelPoints);
    } else {
        state.attemptsLeft--;
        els.attemptsDisplay.innerText = `Intents: ${state.attemptsLeft}`;

        if (clickedBtn) clickedBtn.classList.add('wrong');

        errorHistory.push({
            question: challengeData.promptTex,
            questionN: state.currentOperation,
            errorType: opt.errorType,
            isCorrect: false,
            meta: challengeData.meta,
        });

        const isLastAttempt = state.attemptsLeft <= 0;

        // Mostra la solució correcta només quan s'esgoten els intents
        renderFeedback(opt, isLastAttempt);

        if (isLastAttempt) {
            state.isTransitioning = true;
            recordAnswerToHistory(challengeData.promptTex, opt.tex, false);
            // Sense temporitzador: l'alumne llegeix la solució i clica «Següent →»
            Array.from(els.optionsContainer.children).forEach(b => (b.style.pointerEvents = 'none'));
            _showNextButton(0);
        }
    }
}

// =========================================================================
// 4. Finalitza l'operació actual
// =========================================================================
/**
 * Final d'exercici (encert o intents esgotats): no hi ha temporitzador.
 * Mostra els punts (si n'hi ha) i el botó «Següent →» dins el bloc de feedback;
 * l'alumne decideix quan passar a l'exercici següent.
 */
function _showNextButton(levelPoints) {
    const fc = els.feedback;

    const points = document.createElement('div');
    if (levelPoints > 0) {
        points.className = 'correct-points';
        points.innerText = `⭐ +${levelPoints} punts`;
    }

    const btn = document.createElement('button');
    btn.className = 'btn-next';
    btn.id = 'btn-next';
    btn.type = 'button';
    btn.textContent = state.currentOperation + 1 >= TOTAL_OPERATIONS ? 'Acabar →' : 'Següent →';
    btn.addEventListener(
        'click',
        () => {
            btn.disabled = true;
            _advance();
        },
        { once: true }
    );

    fc.appendChild(points);
    fc.appendChild(btn);
    btn.focus({ preventScroll: true });
    btn.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

/** Passa a l'exercici següent o, si ja són tots, al resum de sessió. */
function _advance() {
    state.currentOperation++;

    if (state.currentOperation >= TOTAL_OPERATIONS) {
        showSessionSummary(); // resum pedagògic → crida endSession() intern
    } else {
        window.buildLevel();
    }
}

// =========================================================================
// 5. Resum pedagògic de sessió
// =========================================================================

/**
 * Construeix i mostra el resum de la sessió a partir d'errorHistory.
 * Amaga #game-screen i mostra #session-summary.
 * El botó "Continua" crida endSession() de game-core.js.
 */
function showSessionSummary() {
    // --- Estadístiques per pregunta ---
    const byQuestion = {};
    errorHistory.forEach(e => {
        if (!byQuestion[e.questionN]) byQuestion[e.questionN] = [];
        byQuestion[e.questionN].push(e);
    });

    let firstTry = 0,
        retried = 0,
        failed = 0;
    Object.values(byQuestion).forEach(entries => {
        const hasCorrect = entries.some(e => e.isCorrect);
        const hasError = entries.some(e => !e.isCorrect);
        if (hasCorrect && !hasError) firstTry++;
        else if (hasCorrect) retried++;
        else failed++;
    });

    // --- Freqüència d'errors conceptuals ---
    const errorCounts = {};
    errorHistory
        .filter(e => !e.isCorrect && e.errorType)
        .forEach(e => {
            errorCounts[e.errorType] = (errorCounts[e.errorType] || 0) + 1;
        });

    const sortedErrors = Object.entries(errorCounts).sort((a, b) => b[1] - a[1]); // de més freqüent a menys

    // --- Construeix el DOM del resum ---
    const panel = document.getElementById('session-summary');
    if (!panel) {
        endSession();
        return;
    }

    // Capçalera de puntuació
    const maxScore = TOTAL_OPERATIONS * 10;
    let html = `
        <div class="summary-score">
            <span class="summary-score-label">Puntuació final</span>
            <span class="summary-score-value">${state.sessionScore} / ${maxScore}</span>
        </div>
        <div class="summary-stats">
            <div class="summary-stat summary-stat--ok">
                <span class="summary-stat-num">${firstTry}</span>
                <span class="summary-stat-desc">correctes a la primera</span>
            </div>
            <div class="summary-stat summary-stat--warn">
                <span class="summary-stat-num">${retried}</span>
                <span class="summary-stat-desc">correctes al segon intent</span>
            </div>
            <div class="summary-stat summary-stat--err">
                <span class="summary-stat-num">${failed}</span>
                <span class="summary-stat-desc">sense resoldre</span>
            </div>
        </div>`;

    if (sortedErrors.length > 0) {
        html += `<div class="summary-errors-title">Errors conceptuals detectats</div>
                 <div class="summary-errors-list">`;
        sortedErrors.forEach(([type, count]) => {
            const hint = DistractorLib.FeedbackHints[type] || '';
            const times = count === 1 ? '1 vegada' : `${count} vegades`;
            html += `
                <div class="summary-error-item">
                    <div class="summary-error-header">
                        <span class="summary-error-type">${_errorTypeLabel(type)}</span>
                        <span class="summary-error-count">${times}</span>
                    </div>
                    ${hint ? `<div class="summary-error-hint">${hint}</div>` : ''}
                </div>`;
        });
        html += `</div>`;
    } else {
        html += `<div class="summary-no-errors">Cap error conceptual detectat. Excel·lent!</div>`;
    }

    html += `<button class="summary-continue-btn" id="summary-continue-btn">Continua</button>`;

    panel.innerHTML = html;

    // Transició: amaga joc, mostra resum
    const gameScreen = document.getElementById('game-screen');
    if (gameScreen) gameScreen.style.display = 'none';
    panel.style.display = 'block';

    document.getElementById('summary-continue-btn').addEventListener('click', () => {
        panel.style.display = 'none';
        errorHistory = []; // reset per a la sessió següent
        // [ROUND 1 — Anti-col·lisió: reset per a la sessió nova]
        if (typeof QuestionBank !== 'undefined') QuestionBank.resetSession();
        endSession();
    });
}

/**
 * Tradueix un errorType intern a una etiqueta llegible per a l'alumne.
 */
function _errorTypeLabel(type) {
    const labels = {
        CHAIN_FORGOT: 'Regla de la cadena oblidada',
        CHAIN_WRONG_COEF: 'Derivada interior incorrecta',
        CHAIN_SIGN: 'Error de signe',
        NO_DERIVATIVE: 'Funció no derivada',
        INTEGRAL_CONFUSION: 'Confusió derivada / integral',
        PRODUCT_FORGOT_SUM: 'Regla del producte mal aplicada',
        PRODUCT_WRONG_ORDER: 'Ordre incorrecte al producte',
        QUOTIENT_SIGN: 'Signe incorrecte al quocient',
        QUOTIENT_DENOM: 'Denominador del quocient incorrecte',
        POWER_FORGOT_R: 'Coeficient de la potència oblidat',
        POWER_WRONG_EXP: 'Exponent de la potència incorrecte',
        LOG_INVERTED: 'Fracció del logaritme invertida',
        LOG_FORGOT_CHAIN: 'Derivada interior del logaritme oblidada',
        LOG_FORGOT_DIVIDE: 'Divisió per f(x) oblidada al logaritme',
        SIN_COS_SWAP: 'Confusió sin / cos en derivar',
    };
    return labels[type] || type;
}

// =========================================================================
// 5. Arrencada automàtica
// =========================================================================
window.addEventListener('DOMContentLoaded', () => {
    if (typeof validateConfig === 'function') validateConfig();
    if (typeof injectSharedHTML === 'function') injectSharedHTML();

    // [ROUND 1 — Anti-col·lisió: reset per a la primera sessió]
    if (typeof QuestionBank !== 'undefined') QuestionBank.resetSession();

    if (typeof startGame === 'function') {
        startGame();
    } else {
        const screen = document.getElementById('game-screen');
        if (screen) screen.style.display = 'block';
        window.buildLevel();
    }
});
